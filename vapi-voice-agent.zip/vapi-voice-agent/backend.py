import datetime as dt
from database import init_db, Appointments, get_db
from fastapi import FastAPI, HTTPException, Depends
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import select
from pydantic import BaseModel
import uvicorn

init_db()

# --- Data Contracts ---

class AppointmentRequest(BaseModel):
    patient_name: str
    reason: str | None = None
    start_time: dt.datetime

class AppointmentResponse(BaseModel):
    id: int
    patient_name: str
    reason: str | None = None
    start_time: dt.datetime
    canceled: bool
    created_at: dt.datetime

class CancelAppointmentRequest(BaseModel):
    patient_name: str
    date: dt.date

class CancelAppointmentResponse(BaseModel):
    canceled_count: int

class ListAppointmentsRequest(BaseModel):
    date: dt.date

# --- App ---

app = FastAPI()

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc):
    print("422 ERROR:", exc.errors())
    return JSONResponse(status_code=422, content={"detail": exc.errors()})


@app.post("/schedule_appointment/", response_model=AppointmentResponse)
def schedule_appointment(request: AppointmentRequest, db: Session = Depends(get_db)):
    new_appointment = Appointments(
        patient_name=request.patient_name,
        reason=request.reason,
        start_time=request.start_time,
    )
    db.add(new_appointment)
    db.commit()
    db.refresh(new_appointment)

    return AppointmentResponse(
        id=new_appointment.id,
        patient_name=new_appointment.patient_name,
        reason=new_appointment.reason,
        start_time=new_appointment.start_time,
        canceled=new_appointment.canceled,
        created_at=new_appointment.created_at,
    )


@app.post("/cancel_appointment/", response_model=CancelAppointmentResponse)
def cancel_appointment(request: CancelAppointmentRequest, db: Session = Depends(get_db)):
    start_dt = dt.datetime.combine(request.date, dt.time.min)
    end_dt = start_dt + dt.timedelta(days=1)

    result = db.execute(
        select(Appointments)
        .where(Appointments.patient_name == request.patient_name)
        .where(Appointments.start_time >= start_dt)
        .where(Appointments.start_time < end_dt)
        .where(Appointments.canceled == False)
    )
    appointments = result.scalars().all()

    if not appointments:
        raise HTTPException(status_code=404, detail="No matching appointment found")

    for appt in appointments:
        appt.canceled = True

    db.commit()
    return CancelAppointmentResponse(canceled_count=len(appointments))


# GET for Streamlit UI
@app.get("/list_appointments/", response_model=list[AppointmentResponse])
def list_appointments_get(date: dt.date, db: Session = Depends(get_db)):
    start_dt = dt.datetime.combine(date, dt.time.min)
    end_dt = start_dt + dt.timedelta(days=1)

    result = db.execute(
        select(Appointments)
        .where(Appointments.canceled == False)
        .where(Appointments.start_time >= start_dt)
        .where(Appointments.start_time < end_dt)
        .order_by(Appointments.start_time.asc())
    )
    appointments = result.scalars().all()

    return [
        AppointmentResponse(
            id=appt.id,
            patient_name=appt.patient_name,
            reason=appt.reason,
            start_time=appt.start_time,
            canceled=appt.canceled,
            created_at=appt.created_at,
        )
        for appt in appointments
    ]

# POST for VAPI
@app.post("/list_appointments/", response_model=list[AppointmentResponse])
def list_appointments_post(request: ListAppointmentsRequest, db: Session = Depends(get_db)):
    return list_appointments_get(request.date, db)


if __name__ == "__main__":
    uvicorn.run("backend:app", host="127.0.0.1", port=4444, reload=True)